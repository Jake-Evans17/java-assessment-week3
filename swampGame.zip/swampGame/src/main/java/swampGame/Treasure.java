package swampGame;

public class Treasure extends ThingOnMap {

	private String token = "[T]";
	
	public Treasure() {
		startPosition();
	}
	
	public void placeOnGrid(Swamp swamp) {
		
		swamp.setGridValue(getxPosition(), getyPosition(), token);
		
	}

}
