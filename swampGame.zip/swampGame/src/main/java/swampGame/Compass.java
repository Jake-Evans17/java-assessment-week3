package swampGame;

public class Compass {
	
	private double distance;

	public double getDistance(Player p, Treasure t) {
		
		int tX = t.getxPosition();
		int tY = t.getyPosition();
		int pX = p.getxPosition();
		int pY = p.getyPosition();
		
		double deltaX = Math.pow(tX - pX, 2);
		double deltaY = Math.pow(tY - pY, 2);
		
		distance = Math.sqrt(deltaX + deltaY);
		
		if (distance > 0) {
			System.out.println("The distance away from the treasure is " + distance);
		}

		return distance;
	}

	public void commentary() {
		if (distance > 20) {
			System.out.println("You are very far.");
		} else if ((distance > 12) && (distance <= 20)) {
			System.out.println("You're quite far");
		} else if ((distance > 7) && (distance <= 12)) {
			System.out.println("You're quite close.");
		} else if ((distance>0) && (distance <= 7)) {
			System.out.println("You are very close.");
		}
		System.out.println();
	}
}
