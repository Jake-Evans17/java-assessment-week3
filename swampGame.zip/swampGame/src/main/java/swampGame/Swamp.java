package swampGame;

public class Swamp {
	
	private String[][] grid = new String[30][30];
	
	public void printGrid() {
		for (int i = 0; i < grid.length; i++) {
			System.out.println();
			for (int j = 0; j < grid[i].length; j++) {
				System.out.print(grid[i][j]);
			}
		}
		System.out.println();
		System.out.println();
	}
	
	public void initialiseGrid() {
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[i].length; j++) {
				this.grid[i][j] = "[ ]";
			}
		}
	}
	
	public String[][] getGrid() {
		
		return grid;
	}

	public void setGrid(String[][] grid) {
		this.grid = grid;
	}

	public void setGridValue(int x, int y, String value) {
		this.grid[x][y] = value; 
	}

	public String getGridValue(int x, int y) {
		return grid[x][y];
	}
}
