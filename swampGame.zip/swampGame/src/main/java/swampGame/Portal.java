package swampGame;

public class Portal extends ThingOnMap {

	private String token = "[@]";
	
	public Portal(Swamp swamp) {
		startPosition();
		placeOnGrid(swamp);
	}
	
	public void placeOnGrid(Swamp swamp) {
		
		boolean foundplace = false;
		while (!foundplace) {
			if (swamp.getGridValue(getxPosition(), getyPosition()).equals("[ ]")) {
				swamp.setGridValue(getxPosition(), getyPosition(), token);
				foundplace = true;
			} else {
				startPosition();
			}
		}

	}
	
	public void enterPortal(Player player, Swamp swamp) {
		
		if ((player.getyPosition() == getyPosition()) && (player.getxPosition() == getxPosition())) {
			System.out.println("Fell through a portal and ended up elsewhere. This kind of thing happens loads in swamps.");
			swamp.setGridValue(getxPosition(), getyPosition(), "[@]");
			player.startPosition();
		}
		

	}
}
