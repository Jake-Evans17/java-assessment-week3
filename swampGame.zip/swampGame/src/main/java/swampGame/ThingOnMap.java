package swampGame;

public abstract class ThingOnMap {
	
	private int xPosition;
	private int yPosition;
	private String token;
	
	public void startPosition() {
		
		setxPosition((int) (Math.random()*20));
		setyPosition((int) (Math.random()*20));
	}
	
	public int getxPosition() {
		return xPosition;
	}
	public void setxPosition(int xPosition) {
		this.xPosition = xPosition;
	}

	public int getyPosition() {
		return yPosition;
	}
	public void setyPosition(int yPosition) {
		this.yPosition = yPosition;
	}


	public void placeOnGrid(Swamp swamp) {
		// TODO Auto-generated method stub
		
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
}
