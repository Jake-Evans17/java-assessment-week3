package swampGame;

public class Narrative {

	public void start() {
		System.out.println("------The Infinite Tessellating Swamp------");
		System.out.println();
		System.out.println("I have endeavoured to live up to the title of this game.");
		System.out.println();
		System.out.println();
	}

	public void intro(Player player) {
		System.out.println();
		System.out.println(player.getName() + ", you find yourself inexplicably in a magical swamp and what to find treasure to make your final days somehow somewhat better.");
		System.out.println("A magic compass is involved for no narrative reason whatsoever and there's also a fairly bland map.");
		System.out.println("Anyway...");
		System.out.println();
	}
	
	public void foundMap(Swamp swamp, int count, int limit) {
		if (count == limit) {
			swamp.printGrid();
			System.out.println("You've found a MAP, but there's not many details on there. Saving that for another power-up, truth be told.");
			System.out.println("Maybe go over to the @ for the sake of something happening.");
			System.out.println();
		} else if (count > limit) {
			swamp.printGrid();
		}
	}
	
	public void foundCompass(Swamp swamp, Compass compass, int count, int limit, Player player, Treasure treasure) {
		if (count == limit) {
			System.out.println("You've found the aformentioned COMPASS that points to the treasure. Dunno how that's possible but just roll with it.");
			compass.getDistance(player, treasure);
			compass.commentary();
		} else if (count > limit) {
			compass.getDistance(player, treasure);
			compass.commentary();
		}
	}
	
	public void end(int count) {
		System.out.println("You've reached the treasure. It looks proper boss with all gold and that. You lived happily ever after. This is the end.");
		System.out.println("It took you " + count + " moves.");
	}

	public void nonEvent1() {
		System.out.println("You've bumped into a wizard. Didn't program him to do much so lets say he a deaf, dumb and blind pinball wizard.");
		System.out.println();
		System.out.println("Do you wanna high-five the guy?");
		String yesOrNo = Input.textInput();
		
		if ((yesOrNo.toLowerCase().equals("yes"))||(yesOrNo.toLowerCase().equals("y"))||(yesOrNo.toLowerCase().equals("ye"))) {
			System.out.println("Wooo!");
		} else {
			System.out.println("You don't high-five him and walk away sullen.");
		}
		System.out.println();
	}
	
	public void nonEvent2() {
		System.out.println("You spot a really nice looking tree and then you remember your impending doom and become sad.");
	}
	
	public void nonEvent3() {
		System.out.println("You bump into an elf. He look a bit annoying to be honest.");
		System.out.println("'Whats your favourite number?' he asks.");
		String num = Input.textInput();
		System.out.println("'" + num + " is a rubbish number.' He leaves in a puff of smoke.");
		
	}

	public void mapEdge(Player player) {
		if ((player.getyPosition() == 0) || (player.getyPosition() == 29) || (player.getxPosition() == 29) || (player.getxPosition() == 0)) {
			System.out.println("You're at the edge of the swamp and are facing an infinite loop.");
			System.out.println("This is the tesselating aspect of the game you were warned about.");
			System.out.println();
		}
	}

}
