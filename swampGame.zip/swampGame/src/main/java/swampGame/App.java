package swampGame;

public class App {

	public static void main(String[] args) {
		
		Narrative narrative = new Narrative();
		
		narrative.start();
		
		String difficulty = Input.setDifficulty();
		int mapLimit = 0;
		int compLimit = 0;
		if (difficulty == "e") {
			mapLimit = 6;
			compLimit = 3;
		} else if (difficulty == "h") {
			mapLimit = 30;
			compLimit = 20;
		} else {
			mapLimit = 15;
			compLimit = 10;
		}
		Swamp swamp = new Swamp();
		swamp.initialiseGrid();
		Treasure treasure = new Treasure();
		Portal p1 = new Portal(swamp);
		Trap t1 = new Trap(swamp);
		Compass comp = new Compass();
		int count = 0;
		System.out.println("What is your name?");
		String name = Input.textInput();
		Player player = new Player(name);
		player.placeOnGrid(swamp);
		
		narrative.intro(player);
				
		while ((player.getyPosition() != treasure.getyPosition()) || (player.getxPosition() != treasure.getxPosition())) {
			Input.setDirection(player, swamp);
			narrative.foundMap(swamp, count, mapLimit);
			narrative.mapEdge(player);
			narrative.foundCompass(swamp, comp, count, compLimit, player, treasure);
			p1.enterPortal(player, swamp);
			t1.enterTrap(player, swamp);
			count++;
			if (count == 8) {
				narrative.nonEvent3();
			} else if (count == 14) {
				narrative.nonEvent2();
			} else if (count == 17) {
				narrative.nonEvent1();
			}
		}
		narrative.end(count);
	}
}
