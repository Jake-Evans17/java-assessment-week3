package swampGame;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Input {

	public static String setDirection(Player player, Swamp swamp) {
		System.out.println("Do you want to go N, S, E or W?");
		String direction = Input.textInput();
		if (direction.toLowerCase().equals("n") || direction.toLowerCase().equals("north")) {
			player.moveN(swamp);
			return "n";
		} else if (direction.toLowerCase().equals("s") || direction.toLowerCase().equals("south")) {
			player.moveS(swamp);
			return "s";
		} else if (direction.toLowerCase().equals("e") || direction.toLowerCase().equals("east")) {
			player.moveE(swamp);
			return "e";
		} else if (direction.toLowerCase().equals("w") || direction.toLowerCase().equals("west")) {
			player.moveW(swamp);
			return "w";
		} else {return "";}
	}
	
	public static String setDifficulty() {
		System.out.println("Easy, Normal or Hard?");
		String difficultyInput = textInput();
		if ((difficultyInput.toLowerCase().equals("easy"))||(difficultyInput.toLowerCase().equals("e"))) {
			System.out.println("The difficulty is set to easy.");
			System.out.println("It's for the best cause on the other ones you have to walk aroung aimlessly for even longer.");
			System.out.println();
			String difficulty = "e";
			return  difficulty;
		} else if ((difficultyInput.toLowerCase().equals("hard"))||(difficultyInput.toLowerCase().equals("h"))) {
			System.out.println("The difficulty is hard.");
			System.out.println("Go for it.");
			System.out.println();
			String difficulty = "h";
			return  difficulty;
		} else {
			System.out.println("The difficulty is normal.");
			System.out.println("Bit bland.");
			System.out.println();
			String difficulty = "n";
			return  difficulty;
		}
	}

    public static String textInput() {

    	String input = "";
    	boolean exit = false;
    	while (exit == false) {
    	Scanner sc = new Scanner(System.in);
    		try {
    			input = sc.nextLine();
    			exit = true;
    			return input;
    		} catch (InputMismatchException e) {
    			System.out.println("Invalid Comment");
    		}
    	}
    	return input;
    }
    
    public static int intInput() {
    	System.out.println();
    	System.out.println();
    	int input = -1;
    	boolean exit = false;
    	while (exit == false) {
    	Scanner sc = new Scanner(System.in);
    		try {
    			input = sc.nextInt();
    			exit = true;
    			return input;
    		} catch (InputMismatchException e) {
    			System.out.println("Invalid Comment");
    		}
    	}
    	return input;
    }
}
