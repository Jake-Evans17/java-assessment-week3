package swampGame;

public abstract class Item {

	private String name;
	private String description;
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public void printDescription() {
		System.out.println(description);
	}
}
