package swampGame;

public class Player extends ThingOnMap {

	private String token = "[P]";
	private String name;
	
	public Player() {
		startPosition();
	}
	
	public Player(String name) {
		startPosition();
		this.setName(name);
		this.token = "[" + name.substring(0, 1) + "]";
	}
	
	public void placeOnGrid(Swamp swamp) {
		
		boolean foundplace = false;
		while (!foundplace) {
			if (swamp.getGridValue(getxPosition(), getyPosition()).equals("[ ]")) {
				swamp.setGridValue(getxPosition(), getyPosition(), token);
				foundplace = true;
			} else {
				startPosition();
			}
		}

	}

	public void moveN(Swamp swamp) {

		swamp.setGridValue(getxPosition(), getyPosition(), "[ ]");
		
		if (getxPosition() == 0) {
			setxPosition(29);
			System.out.println("You have entered through a portal that's here cause the narrator/coder says so.");
		} else {
			setxPosition(getxPosition() - 1);
		}
		
		swamp.setGridValue(getxPosition(), getyPosition(), token);

	}

	public void moveS(Swamp swamp) {
		
		swamp.setGridValue(getxPosition(), getyPosition(), "[ ]");
		
		if (getxPosition() == 29) {
			setxPosition(0);
			System.out.println("You have entered through a portal that's here cause the narrator/coder says so.");
		} else {
			setxPosition(getxPosition() + 1);
		}
		
		swamp.setGridValue(getxPosition(), getyPosition(), token);
		
	}

	public void moveE(Swamp swamp) {
		
		swamp.setGridValue(getxPosition(), getyPosition(), "[ ]");
		
		if (getyPosition() == 29) {
			setyPosition(0);
			System.out.println("You have entered through a portal that's here cause the narrator/coder says so.");
		} else {
			setyPosition(getyPosition() + 1);
		}

		swamp.setGridValue(getxPosition(), getyPosition(), token);
	}

	public void moveW(Swamp swamp) {
		
		swamp.setGridValue(getxPosition(), getyPosition(), "[ ]");
		
		if (getyPosition() == 0) {
			setyPosition(29);
			System.out.println("You have entered through a portal that's here cause the narrator/coder says so.");
		} else {
			setyPosition(getyPosition() - 1);
		}

		swamp.setGridValue(getxPosition(), getyPosition(), token);

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	


}

