package swampGame;

public class Trap extends ThingOnMap {

	private String token = "[#]";
	
	public Trap(Swamp swamp) {
		startPosition();
		placeOnGrid(swamp);
	}
	
	public void placeOnGrid(Swamp swamp) {
		
		boolean foundplace = false;
		while (!foundplace) {
			if (swamp.getGridValue(getxPosition(), getyPosition()).equals("[ ]")) {
				swamp.setGridValue(getxPosition(), getyPosition(), token);
				foundplace = true;
			} else {
				startPosition();
			}
		}

	}
	
	public void enterTrap(Player player, Swamp swamp) {
		
		if ((player.getyPosition() == getyPosition()) && (player.getxPosition() == getxPosition())) {
			System.out.println("You steped on a trap and died in a very extrodinary and gruesome way. Use your imagination.");
			System.out.println("You're a ghost now.");
			System.out.println("");
			swamp.setGridValue(getxPosition(), getyPosition(), "[@]");
			player.startPosition();
		}
		

	}
}
